#!python3
# coding = utf-8

import ctypes
import ctypes.wintypes as wintypes
import os


def set_windows_desktop_wallpaper(fpath: str) -> bool:
    """
    set Windows Desktop Wallpaper.

    BOOL WINAPI SystemParametersInfo(
      _In_    UINT  uiAction,
      _In_    UINT  uiParam,
      _Inout_ PVOID pvParam,
      _In_    UINT  fWinIni
    )
    
    :param fpath: path to background image file.
    :return:
    """
    fpath = os.path.abspath(fpath)
    SPI = ctypes.windll.User32.SystemParametersInfoW
    SPI_SETDESKWALLPAPER = wintypes.UINT(0x0014)
    SPIF_UPDATEINIFILE = wintypes.UINT(0x0001)
    
    return SPI(SPI_SETDESKWALLPAPER, 0, fpath, SPIF_UPDATEINIFILE)


if __name__ == "__main__":
  import sys
  imgf = os.path.abspath(sys.argv[1])
  if os.path.isfile(imgf):
    set_windows_desktop_wallpaper(imgf)
